

#import "PlatformWrapper.h"
#import "mach/mach.h"
#import "mach/mach_host.h"

#import <AddressBook/AddressBook.h>
#import <CoreTelephony/CTCarrier.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMessageComposeViewController.h>

#define OUTPUT_LOG(...) if (self.debug) NSLong(__VA_ARGS__);

@interface PlatformWrapper()

@end

@implementation PlatformWrapper


#pragma mark - InterfaceUser

+ (NSString*) getPhoneNumber
{
    return @"";
}
+ (NSString*) getMailAccount
{
    return @"";
}
+ (NSString*) getDeviceModel
{
    return [[UIDevice currentDevice] localizedModel];
}

+ (NSNumber*) getVersionCode
{
   return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleVersion"];
}
+ (NSString*) getAppVersion
{
    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
}
+ (NSString*) getOSVersion
{
    return [[UIDevice currentDevice] systemVersion];
}


+ (NSString*) getDownloadSource
{
    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"downloadSource"];
}



+ (NSNumber*) getStoreType
{
//    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"storeType"];
    return [NSNumber numberWithInteger:5];

}
+ (NSString*) getDeviceID
{
    NSUUID *identify = [[UIDevice currentDevice] identifierForVendor];
    NSString *str = [identify UUIDString];
    return str;
}

+ (NSString*) getBundleId
{
    return [[NSBundle mainBundle] bundleIdentifier];
}

+ (NSString*) getDeviceToken
{
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    NSString *str = [standardUserDefaults valueForKey:@"deviceToken"];
    if (str == NULL)
        str = @"";
    return str;
}


+ (void) logFabric
{
    
}
+ (void) logAppFlyerPurchase: (NSString*) data
{
    
}
+ (void) hideNavigation
{
    
}

+ (NSNumber*) isInstalledApp: (NSString*) data
{
    return 0;
}

+ (NSNumber*) isInstalledFacebookApp
{
    NSArray* fbSchemes = @[@"fbapi://", @"fb-messenger-api://", @"fbauth2://", @"fbshareextension://"];
    BOOL isInstalled = 0;
    
    for (NSString* fbScheme in fbSchemes) {
        isInstalled = [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:fbScheme]];
        if(isInstalled) break;
    }
    
    if (isInstalled) {
        return [NSNumber numberWithInt: 1];
    }
    else{
        return [NSNumber numberWithInt: 0];
    }
}

+ (NSNumber*) isInstalledLineApp
{
    return 0;
}

+ (NSNumber*) isInstalledZaloApp
{
    return 0;
}

+ (UIViewController *)getCurrentRootViewController {
    
    UIViewController *result = nil;
    
    // Try to find the root view controller programmically
    
    // Find the top window (that is not an alert view or other window)
    UIWindow *topWindow = [[UIApplication sharedApplication] keyWindow];
    if (topWindow.windowLevel != UIWindowLevelNormal)
    {
        NSArray *windows = [[UIApplication sharedApplication] windows];
        for(topWindow in windows)
        {
            if (topWindow.windowLevel == UIWindowLevelNormal)
                break;
        }
    }
    
    UIView *rootView = [[topWindow subviews] objectAtIndex:0];
    id nextResponder = [rootView nextResponder];
    
    if ([nextResponder isKindOfClass:[UIViewController class]])
        result = nextResponder;
    else if ([topWindow respondsToSelector:@selector(rootViewController)] && topWindow.rootViewController != nil)
        result = topWindow.rootViewController;
    else
        NSAssert(NO, @"Could not find a root view controller.");
    
    return result;
}

+ (void) copyTextToClipboard: (NSString *)text
{
    NSLog(@"copyTextToClipboard: %@", text);
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = text;
}

/*** Recording ***/



+(NSString*) NSStringFromOSStatus:(OSStatus) errCode
{
    if (errCode == noErr)
        return @"noErr";
    char message[5] = {0};
    *(UInt32*) message = CFSwapInt32HostToBig(errCode);
    return [NSString stringWithCString:message encoding:NSASCIIStringEncoding];
}

@end
