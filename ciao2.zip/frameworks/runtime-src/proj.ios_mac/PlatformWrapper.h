

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "AppController.h"

@interface PlatformWrapper : NSObject  {

}

@property BOOL debug;
//@property NSString * filename;

// ----- Interface of GooglePlay

+ (NSString*) getPhoneNumber;
+ (NSString*) getMailAccount;
+ (NSString*) getDeviceModel;

+ (NSNumber*) getVersionCode;
+ (NSString*) getAppVersion;
+ (NSString*) getOSVersion;

+ (NSString*) getDownloadSource;

+ (NSNumber*) getStoreType;
+ (NSString*) getDeviceID;
+ (NSString*) getBundleId;
+ (void) logFabric;
+ (void) logAppFlyerPurchase: (NSString*) data;
+ (void) hideNavigation;
+ (NSNumber*) isInstalledApp: (NSString*) data;
+ (NSNumber*) isInstalledFacebookApp;
+ (NSNumber*) isInstalledLineApp;
+ (NSNumber*) isInstalledZaloApp;

+ (UIViewController *) getCurrentRootViewController;
@end
