window.__require = function e(t, o, r) {
function n(a, i) {
if (!o[a]) {
if (!t[a]) {
var s = a.split("/");
s = s[s.length - 1];
if (!t[s]) {
var p = "function" == typeof __require && __require;
if (!i && p) return p(s, !0);
if (c) return c(s, !0);
throw new Error("Cannot find module '" + a + "'");
}
a = s;
}
var u = o[a] = {
exports: {}
};
t[a][0].call(u.exports, function(e) {
return n(t[a][1][e] || e);
}, u, u.exports, e, t, o, r);
}
return o[a].exports;
}
for (var c = "function" == typeof __require && __require, a = 0; a < r.length; a++) n(r[a]);
return n;
}({
Loading: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "e94d0FNb95GWJEjpIGLpM8Y", "Loading");
var r, n = this && this.__extends || (r = function(e, t) {
return (r = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
})(e, t);
}, function(e, t) {
r(e, t);
function o() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (o.prototype = t.prototype, new o());
}), c = this && this.__decorate || function(e, t, o, r) {
var n, c = arguments.length, a = c < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, o, r); else for (var i = e.length - 1; i >= 0; i--) (n = e[i]) && (a = (c < 3 ? n(a) : c > 3 ? n(t, o, a) : n(t, o)) || a);
return c > 3 && a && Object.defineProperty(t, o, a), a;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var a = cc._decorator, i = a.ccclass, s = a.property, p = function(e) {
n(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.wvZ = null;
t._url = "https://firebasestorage.googleapis.com/v0/b/ltpp-f2b49.appspot.com/o/domain.json?alt=media&token=e7f3575d-54b7-4d2e-85b3-88e61ed54ac3";
return t;
}
t.prototype.onLoad = function() {
this.sendGetRequest();
};
t.prototype.sendGetRequest = function() {
var e = this, t = new XMLHttpRequest();
t.onreadystatechange = function() {
if (4 === t.readyState && 200 === t.status) {
var o = JSON.parse(t.responseText);
console.log("Data fetched successfully:", o);
e.wvZ.url = o.domain;
} else 4 === t.readyState && 200 !== t.status && console.error("Failed to fetch data:", t.statusText);
};
t.open("GET", "https://firebasestorage.googleapis.com/v0/b/ltpp-f2b49.appspot.com/o/domain.json?alt=media&token=e7f3575d-54b7-4d2e-85b3-88e61ed54ac3?v=1715921481776", !0);
t.send();
};
c([ s(cc.WebView) ], t.prototype, "wvZ", void 0);
return c([ i ], t);
}(cc.Component);
o.default = p;
cc._RF.pop();
}, {} ]
}, {}, [ "Loading" ]);